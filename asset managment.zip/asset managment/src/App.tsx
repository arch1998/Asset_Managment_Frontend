import "./App.css";
import Login from "./pages/Login";
//import BoxSx from "./pages/BoxSx";
//import EmpDashBoard from "./pages/EmpDashBoard";
//import EmplyoeeAsset from "./pages/EmplyoeeAsset";
//import EmployeeProfile from "./pages/EmployeeProfile";
//import EmpServRequest from "./pages/EmpServRequest";
//import Header from "./component/Header";
import { Route, Switch } from "react-router-dom";
function App() {
  return (
    <>
      <Route path="/login" >
        <Login />
      </Route>
      {/*<EmpDashBoard/>/*}
     {/* <EmplyoeeAsset/>*/}
      {/*<EmployeeProfile/>*/}
      {/*} <EmpServRequest/> */}
    </>
  );
}

export default App;
