import React from 'react'

import Header from '../component/Header'


function EmplyoeeAsset() {
  return (
   <>
   <div>
   <Header/>
        
      </div>
   </>
  )
}

export default EmplyoeeAsset