import React from "react";
import mainLogo from "../utils/1.png";
import PersonIcon from "@mui/icons-material/Person";
import "./DasBoard.css";
//import Box from "@mui/material/Box";
import { Grid } from "@mui/material";
import WebAssetIcon from "@mui/icons-material/WebAsset";
import DeviceUnknownIcon from "@mui/icons-material/DeviceUnknown";

function EmpDashBoard() {
  return (
    <>
      <div className="header">
        <div className="img">
          <img src={mainLogo} alt="" width="250px" height="60" />
        </div>
        <PersonIcon
          sx={{
            width: 50,
            height: 50,
            position: "absolute",
            right: 0,
            top: 30,
          }}
        ></PersonIcon>
      </div>

      <h2 style={{ marginTop: 40 }}> DashBoard </h2>
      <div>
        <Grid container justifyContent="space-around" sx={{ marginTop: 12 }}>
          <div>
            <Grid
              item
              sx={{
                width: "250px",
                height: "244px",
                border: "2px solid black",
                backgroundColor: "#cbcbcb",
              }}
            >
              <PersonIcon
                sx={{
                  width: 100,
                  height: 100,
                  marginTop: 7,
                }}
              ></PersonIcon>
            </Grid>
          </div>
          <Grid
            item
            sx={{
              width: "250px",
              height: "244px",
              border: "2px solid black",
              backgroundColor: "#cbcbcb",
            }}
          >
            <WebAssetIcon
              sx={{
                width: 100,
                height: 100,
                marginTop: 7,
              }}
            ></WebAssetIcon>
          </Grid>
          <Grid
            item
            sx={{
              width: "250px",
              height: "244px",
              border: "2px solid black",
              backgroundColor: "#cbcbcb",
            }}
          >
            <DeviceUnknownIcon
              sx={{
                width: 100,
                height: 100,
                marginTop: 7,
              }}
            ></DeviceUnknownIcon>
          </Grid>
        </Grid>
      </div>
    </>
  );
}

export default EmpDashBoard;
