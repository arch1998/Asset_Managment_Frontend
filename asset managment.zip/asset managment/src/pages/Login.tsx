import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";
import Button from "@mui/material/Button";
import mainLogo from "../utils/1.png";

function Login() {
  return (
    <>
      <Box
        sx={{
          width: "50%",
          height: "600px",
          backgroundColor: "#cbcbcb",
          margin: "3% auto",
        }}
      >
        <form
          style={{
            display: "flex",
            width: "100%",
            height: "100%",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
          }}
        >
          <img
            src={mainLogo}
            alt=""
            style={{ width: "280px", height: "77px", marginBottom: "55px" }}
          />
          <div style={{ display: "flex", width: "500px" }}>
            <PersonIcon style={{ fontSize: "50px", color: "grey" }} />
            <TextField
              id="demo-helper-text-misaligned-no-helper"
              label="Name"
              style={{ background: "white", outline: "none", width: "100%" }}
            />
          </div>
          <br />
          <br />
          <div style={{ display: "flex", width: "500px" }}>
            <LockIcon style={{ fontSize: "50px", color: "grey" }} />
            <TextField
              type="password"
              id="demo-helper-text-misaligned-no-helper"
              label="Password"
              style={{ background: "white", outline: "none", width: "100%" }}
            />
          </div>
          <div style={{ marginTop: "50px" }}>
            <Button variant="contained">Log In</Button>
          </div>
        </form>
      </Box>
    </>
  );
}

export default Login;
